def raiz(N,a):
    return pow(a,1/N)
    #return a**(1/N)

