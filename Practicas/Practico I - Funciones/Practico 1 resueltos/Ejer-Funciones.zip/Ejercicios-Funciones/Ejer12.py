def buscar(x,lista):
    for ind in range(len(lista)):
        if lista[ind]==x:
            return ind
    return None

