from math import pi

def area_circulo(r):
    return pi*(r**2) 


