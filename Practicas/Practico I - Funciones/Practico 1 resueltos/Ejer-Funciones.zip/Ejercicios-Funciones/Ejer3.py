def primera_may(cad):
    if (cad[0]>='A') and (cad[0]<='Z'):
        return True
    return False


